This is a skeleton file for running RingoJS in any Servlet container.
To create a new Java web app based on this skeleton run the
following command:

  ringo-admin create --java-webapp

