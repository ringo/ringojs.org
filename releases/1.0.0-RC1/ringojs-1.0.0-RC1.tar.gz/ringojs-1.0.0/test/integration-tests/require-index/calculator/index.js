exports.add = require("./adder").add;
exports.substract = require("./substractor").substract;