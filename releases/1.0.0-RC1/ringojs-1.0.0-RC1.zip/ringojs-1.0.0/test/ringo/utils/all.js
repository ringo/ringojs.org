exports.testArrays         = require('./arrays_test');
exports.testDates          = require('./dates_test');
exports.testFiles          = require('./files_test');
exports.testHttp           = require('./http_test');
exports.testObjects        = require('./objects_test');
exports.testStrings        = require('./strings_test');
