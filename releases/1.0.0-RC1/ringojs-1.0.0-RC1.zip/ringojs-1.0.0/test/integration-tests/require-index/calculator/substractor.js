exports.substract = function(a, b) {
    return a - b;
};