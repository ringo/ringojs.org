exports.b = function () {
    return require('b');
};
