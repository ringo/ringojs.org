require('b').monkey = 10;
